export default function TermsPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-12">
      <h1 className="text-3xl font-semibold">Terms of Service</h1>
      <p className="mt-4 text-slate-600">This is a placeholder. Add your terms here.</p>
    </div>
  )
}
