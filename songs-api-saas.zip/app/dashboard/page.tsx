import { OverviewClient } from "@/components/dashboard/overview-client"

export default function DashboardOverviewPage() {
  return (
    <div className="space-y-6">
      <OverviewClient />
    </div>
  )
}
